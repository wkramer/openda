package thredds.catalog2;

/**
 * _more_
 *
 * @author edavis
 * @since 4.0
 */
public interface ThreddsCatalogObject
{
  public CatalogIssues getIssues();
}
